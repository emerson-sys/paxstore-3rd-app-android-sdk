package com.pax.android.demoapp;

import android.content.Context;
import android.content.Intent;

public interface FragmentReceiver {
    void onRecive(Context context, Intent intent);
}
