package com.pax.android.demoapp;

import android.widget.TextView;

/**
 * Created by yinfei on 2016/9/5.
 */

public class ViewHolder {
    public TextView label;
    public TextView value;
}
